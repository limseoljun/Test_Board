/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module Test_Board {
	requires java.base;
}