package com.test.data;

import java.time.LocalDate;
import java.util.ArrayList;

public class Data {
	static public ArrayList<Data> posts;
	
	
	static public void loadData() {
		posts = new ArrayList<>();
	}
	static public int no = 0;
	public int p_No;
	public String title;
	public String writer;
	public String content;
	public int join;
	public String date;
	public String pass;
	public String pw;
	public String id;

	public Data(String title, String writer, String content, int join, String pass) {
		no= no+1;
		p_No=no;
		this.title = title;
		this.writer = writer;
		this.content = content;
		this.join = join;
		this.pass = pass;
		LocalDate now = LocalDate.now();
		date = now.toString();
	}
	public void infoRead() {
		System.out.println("글 번호: " + p_No);
		System.out.print("제목: "+title+" ");
		System.out.print("작성자: "+writer+" ");
		System.out.print("조회수: "+ join+" ");
		System.out.println("");
	}
	public void infoList() {
		System.out.print("제목: "+title+" ");
		System.out.print("작성자: "+writer+" ");
		System.out.print("조회수: "+ join+" ");
		System.out.println("작성일:"+date);
		System.out.println("내용: "+ content);
		System.out.println("");
	}
	
	
}
