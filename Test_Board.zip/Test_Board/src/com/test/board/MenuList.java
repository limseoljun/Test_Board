package com.test.board;

import java.sql.SQLException;

import com.test.util.Ci;

public class MenuList {
	public static final int PER_PAGE = 3;

	static void run() {
		Board.getdbPostCount();
		int totalPage = 0;
		if (Board.getdbPostCount() % PER_PAGE > 0) {
			totalPage = Board.getdbPostCount() / PER_PAGE + 1;
		} else {
			totalPage = Board.getdbPostCount() / PER_PAGE;
		}
		System.out.println("총페이지 수: " + totalPage);
		int startIndex = 0; // 현재 페이지의 첫 글 인덱스
		int currentPage = 0;
		while (true) {
			String cmd = Ci.r("[페이지 입력/s.검색/x.나가기]"); // 현재 페이지
			if (cmd.equals("x")) {
				break;
			} else if (cmd.equals("s")) {
				String cmd2 = Ci.r("글 제목 입력");
				int check = 0;
				try {
					Board.result = Board.st.executeQuery("select * from board where b_title like '%" + cmd2 + "%'");
					while (Board.result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
						check = 1;
						String no = Board.result.getString("b_no");
						String title = Board.result.getString("b_title");
						String id = Board.result.getString("b_id");
						String datetime = Board.result.getString("b_datetime");
						System.out.println("번호:" + no + " 제목 : " + title + " 작성자: " + id + " 작성 시간: " + datetime);
					}
				} catch (SQLException e) {
					System.out.println("존재하지 않는 글");
				}
				if (check == 0) {
					System.out.println("존재하지 않는 글 입니다.");
				} else {
				}
				break;
			}
				currentPage = Integer.valueOf(cmd);
				if (currentPage > totalPage || currentPage < 1) {
					System.out.println("페이지 범위에 맞는 값을 넣어주세요");
					continue;
				}
				startIndex = (currentPage - 1) * PER_PAGE; // 페이지의 첫 인덱스를 구해서 계산해서 저장
				System.out.println("==========================================");
				System.out.println("================= 글리스트 ==================");
				System.out.println("==========================================");
				try {
					Board.result = Board.st.executeQuery("select * from board limit  " + startIndex + "," + PER_PAGE);
					while (Board.result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
						String no = Board.result.getString("b_no");
						String title = Board.result.getString("b_title");
						String id = Board.result.getString("b_id");
						String datetime = Board.result.getString("b_datetime");
						System.out.println("번호:" + no + " 제목 : " + title + " 작성자: " + id + " 작성 시간: " + datetime);
					}
				} catch (SQLException e) {
					System.out.println("페이지 입력해주세요");
				}
				break;
			}
		}
}