package com.test.board;

import com.test.data.Data;

public class MenuList {
	static void run() {
		System.out.println("<<리스트>");
		for(Data p:Data.posts) {
		p.infoList();
		}
	}
}
