package com.test.board;

import com.test.data.Data;
import com.test.util.Ci;

public class MenuRevise {
	static void run() {
		loop: while (true) {
			System.out.println("<<수정>>");
			for (Data p : Data.posts) {
				p.infoRead();
			}
			String cmd = Ci.r("【 수정할 글의 번호 입력 / x.나가기 ]");
			if (cmd.equals("x")) {
				break loop;
			} else {
				for (Data p : Data.posts) {
					if (cmd.equals(p.p_No + "")) {
						System.out.println(p.p_No+"번 글의 수정목록 선택");
						cmd = Ci.r("[ 1.제목 2.작성자 3.내용 x.나가기]");
						switch (cmd) {
						case "1":
							System.out.println("제목을 바꾸겠습니까?");
							cmd = Ci.r("[ 1.네 2.아니요 ]");
							switch (cmd) {
							case "1":
								while (true) {
									p.title = Ci.r("글제목");
									if (p.title.length() > 0) {
										break;
									} else {
										System.out.println("수정해 주세요");
									}
								}
								break;

							case "2":
								break;
							}
						case "2":
							System.out.println("작성자를 바꾸겠습니까?");
							cmd = Ci.r("[ 1.네 2.아니요 ]");
							switch (cmd) {
							case "1":
								while (true) {
									p.writer = Ci.r("작성자");
									if (p.writer.length() > 0) {
										break;
									} else {
										System.out.println("수정해 주세요");
									}
								}
								break;
							case "2":
								break;
							}
						case "3":
							System.out.println("내용을 바꾸겠습니까?");
							cmd = Ci.r("[ 1.네 2.아니요 ]");
							switch (cmd) {
							case "1":
								while (true) {
									p.content = Ci.rl("내용");
									if (p.content.length() > 0) {
										break;
									} else {
										System.out.println("수정해 주세요");
									}
								}
								break;
							case "2":
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
