package com.test.board;

import com.test.data.Data;
import com.test.util.Ci;

public class MenuRead {
	static void run() {
		System.out.println("<<읽기>>");
		String cmd = Ci.r("읽을 글의 번호");
		for(Data p:Data.posts) {
			if(cmd.equals(p.p_No+"")) {
				p.infoRead();
				p.join=p.join+1;
			}
		}

	}

}
