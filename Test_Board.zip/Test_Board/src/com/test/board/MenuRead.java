package com.test.board;

import java.sql.SQLException;

import com.test.util.Ci;

public class MenuRead {
	static void run() {
		System.out.println("<<읽기>>");
		try {
			Board.result = Board.st.executeQuery("select * from board");
			while (Board.result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String no = Board.result.getString("b_no");
				String title = Board.result.getString("b_title");
				String id = Board.result.getString("b_id");
				System.out.println("번호:" + no + " 제목 : " + title + " 작성자: " + id);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String cmd = Ci.r("읽을 글의 번호");
		try {
			Board.result = Board.st.executeQuery("select * from board where b_no =" + cmd);
			Board.result.next(); // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
			String title = Board.result.getString("b_title"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			String content = Board.result.getString("b_text"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			System.out.println("글제목: " + title);
			System.out.println("글내용: " + content);
			MenuReply.list(Integer.parseInt(cmd));
		} catch (SQLException e) {
			System.out.println("존재하지 않은 글 입니다.");
//			e.printStackTrace();
		}
	}
}
