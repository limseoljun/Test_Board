package com.test.board;

import com.test.data.Data;
import com.test.util.Ci;

public class MenuDel {
	static void run() {
		loop: while (true) {
			System.out.println("<<삭제>>");
			for (Data p : Data.posts) {
				p.infoRead();
			}
			String cmd = Ci.r("【 삭제할 글의 번호 입력 / x.나가기 ]");
			if (cmd.equals("x")) {
				break loop;
			} else {
				for (Data p : Data.posts) {
					if (cmd.equals(p.p_No + "")) {
						System.out.println("글을 정말 삭제 하시겠습니까?");
						cmd = Ci.r("[1. 삭제 2. 취소]");
						switch (cmd) {
						case "1":
							Data.posts.remove(p);
							System.out.println(p.p_No + "번 게시물이 삭제 되었습니다.");
							break;
						case "2":
							break;
						}
						break;
					}
				}
			}
		}
	}
}
