package com.test.board;

import java.sql.SQLException;

import com.test.member.MemberLogin;
import com.test.site.SiteMain;
import com.test.util.Ci;

public class MenuWrite {
	static void run() {
		String title;
		while(true) {
			title=Ci.rl("글제목");
			if(title.length()>0) {
				break;
			}else {
				System.out.println("작성해주세요");
			}
		}
		
		String content;
		while(true) {
			content=Ci.rl("내용");
			if(content.length()>0) {
				break;
			}else {
				System.out.println("작성해주세요");
			}
		}
//		
//		String pass;
//		while(true) {
//			pass=Ci.a("비밀번호");
//			if(pass.length()>0) {
//				break;
//			}else {
//				System.out.println("작성해주세요");
//			}
//		}
		try {
			Board.st.executeUpdate("insert into board (b_title,b_id,b_datetime,b_text,b_hit,log_no)"
					+" values ('"+title+"','"+SiteMain.loginedId+"',now(),'"+content+"',0,'"+MemberLogin.log_no+"')");
			System.out.println("글등록 완료");
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
}
