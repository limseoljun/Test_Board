package com.test.board;

import com.test.data.Data;
import com.test.util.Ci;

public class MenuWrite {
	static void run() {
		System.out.println("<<쓰기>>");
		
		String title;
		while(true) {
			title=Ci.r("글제목");
			if(title.length()>0) {
				break;
			}else {
				System.out.println("작성해주세요");
			}
		}
		
		String writer;
		while(true) {
			writer=Ci.r("작성자");
			if(writer.length()>0) {
				break;
			}else {
				System.out.println("작성해주세요");
			}
		}
		
		String content;
		while(true) {
			content=Ci.r("내용");
			if(writer.length()>0) {
				break;
			}else {
				System.out.println("작성해주세요");
			}
		}
		Data p = new Data(title, writer, content, 0);
		Data.posts.add(p);
		System.out.println("작성 완료");
	}
}
