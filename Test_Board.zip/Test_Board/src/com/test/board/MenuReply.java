package com.test.board;

import java.sql.SQLException;

import com.test.display.Disp;
import com.test.site.SiteMain;
import com.test.util.Ci;

public class MenuReply {
	static public void list(int oriNo) {
		Disp.replyBar();
		String sql = "select * from reply where b_reply_ori=" + oriNo;
		try {
//			System.out.println("전송한sql문:"+sql);
			Board.result = Board.st.executeQuery(sql);
			while (Board.result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String re_no =  Board.result.getString("re_no");
				String b_reply_text = Board.result.getString("b_reply_text");
				String b_reply_id = Board.result.getString("b_reply_id");
				System.out.println("댓글 번호: " + re_no + "  댓글 내용:" + b_reply_text + "  댓글 작성자: " + b_reply_id);
				System.out.println("=================================================");
			}
		} catch (SQLException e) {
			System.out.println("존재하지 않는 글입니다.");
		}

		while (true) {
			String cmd = Ci.rl("[ 삭제할 댓글 번호 입력 /x.나가기 ]");
			if (cmd.equals("x")) {
				break;
			} else {
				try {
					Board.result = Board.st.executeQuery("select * from reply where re_no = '" + cmd + "'");
					Board.result.next(); // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
//					String re_pass = Board.result.getString("b_reply_pass");
					String re_text = Board.result.getString("b_reply_text");
					String re_id = Board.result.getString("b_reply_id");
					System.out.println("[" + " 댓글 : " + re_text + " 작성자: " + re_id + "] 을 선택 하였습니다.");
					if (SiteMain.loginedId.equals(Board.result.getString("b_reply_id"))) {
						Board.dbExecuteUpdate("delete from reply where re_no = '" + cmd + "'");
						System.out.println(" 제목 : " + re_text + " 가/이 삭제 되었습니다.");
					} else {
						System.out.println("작성자가 아닙니다.");
					}
				} catch (SQLException e) {
					System.out.println("존재하지 않은 댓글 입니다.");
				}
				break;
			}
		}
	}

	static void run() {

		System.out.println("<<댓글>>");
		try {
			Board.result = Board.st.executeQuery("select * from board");
			while (Board.result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String no = Board.result.getString("b_no");
				String title = Board.result.getString("b_title");
				String id = Board.result.getString("b_id");
				System.out.println("번호:" + no + " 제목 : " + title + " 작성자: " + id);
			}
		} catch (SQLException e) {
			System.out.println("존재하지 않은 글 입니다.");
		}
		String re_no;
		while (true) {
			re_no = Ci.rl("댓글 달 글 번호");
			if (re_no.length() > 0) {
				break;
			} else {
				System.out.println("작성해주세요");
			}
		}
		String re_con;
		while (true) {
			re_con = Ci.r("댓글 내용");
			if (re_con.length() > 0) {
				break;
			} else {
				System.out.println("작성해주세요");
			}
		}
//		String re_pass;
//		while (true) {
//			re_pass = Ci.a("비밀번호");
//			if (re_pass.length() > 0) {
//				break;
//			} else {
//				System.out.println("작성해주세요");
//			}
//		}
		try {
			Board.st.executeUpdate(
					"insert into reply (b_reply_ori,b_reply_id,re_datetime,b_reply_text)" + " values ('"
							+ re_no + "','" + SiteMain.loginedId + "',now(),'" + re_con + "')");
			System.out.println("댓글등록 완료");
		} catch (SQLException e) {
			System.out.println("존재하지 않은 글 입니다.");
		}
	}
}
