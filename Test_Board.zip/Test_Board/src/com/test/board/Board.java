package com.test.board;

import com.test.data.Data;
import com.test.display.Disp;

public class Board {
	public static final String VERSION = "test";
	public static final String TITLE = "임설준 게시판 (" + VERSION + ") feat. sm.ahn";
	void run() {
		Data.loadData();
		Disp.title();
		Menu.run();
	}
}
