package com.test.site;

import com.test.board.Board;
import com.test.display.Disp;
import com.test.member.MemberLogin;
import com.test.member.MemberResiter;
import com.test.util.Ci;

public class SiteMain {
	static private String cmd = "";
	public static String loginedId = null;

	static public void run() {
		Board.dbInit();
		loop: while (true) {
			Disp.title();
			if (loginedId == null) {
				cmd = Ci.r("[1]회원가입 [2]로그인 [3]관리자 [4]게시판(임시입구) [e]프로그램종료");
			} else {
				System.out.println(loginedId + " 고객님 환영합니다.");
				cmd = Ci.r("[1]회원가입 [2]로그아웃 [3]관리자 [4]게시판(임시입구) [e]프로그램종료");
			}
			switch (cmd) {
			case "1":
				MemberResiter.run();
				break;
			case "2":
				if (loginedId == null) {
					loginedId = MemberLogin.run();
				} else {
					System.out.println("로그아웃 되었습니다.");
					loginedId = null;
				}
				break;
			case "3":
				break;
			case "e":
				System.out.println("프로그램 종료");
				break loop;
			case "4":
				if (loginedId == null) {
					System.out.println("로그인 해주세요.");
				} else {
					Board.run();
				}
				break;
			default:
				System.out.println("장난치지 마세요");
			}
		}
	}
}
