package com.test.display;

import com.test.board.Board;

public class Disp {
	public static void title() {
		for(int i=0;i<32;i++) {
			System.out.print("🐈‍");
		}
		System.out.println();
		System.out.print("🐈‍");
		for(int i=0;i<10;i++) {
			System.out.print(" ");
		}
		System.out.print(Board.TITLE);
		for(int i=0;i<10;i++) {
			System.out.print(" ");
		}
		System.out.print("🐈‍");
		System.out.println();
		for(int i=0;i<32;i++) {
			System.out.print("🐈‍");
		}
		System.out.println();
	}
	public static void menuMain() {
		System.out.print("🐈‍");
		System.out.print("[1.글 리스트/2.글읽기/3.글쓰기/4.글삭제/5.글수정/6.댓글/e.뒤로가기]");
		System.out.print("🐈‍");
		System.out.println();
	}
	public static void replyBar() {
		System.out.println("================= 댓글 리스트 ==================");
	}	
}
