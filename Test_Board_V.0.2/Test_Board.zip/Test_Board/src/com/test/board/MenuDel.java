package com.test.board;

import java.sql.SQLException;

import com.test.member.MemberLogin;
import com.test.site.SiteMain;
import com.test.util.Ci;

public class MenuDel {
	static void run() {
		loop: while (true) {
			System.out.println("<<삭제>>");
			try {
				Board.result = Board.st.executeQuery("select * from board");
				while (Board.result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
					String no = Board.result.getString("b_no");
					String title = Board.result.getString("b_title");
					String id = Board.result.getString("b_id");
					System.out.println("번호:" + no + " 제목 : " + title + " 작성자: " + id);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			String cmd = Ci.r("【 삭제할 글의 번호 입력 / x.나가기 ]");
			if (cmd.equals("x")) {
				break loop;
			} else {
				try {
					Board.result = Board.st.executeQuery("select * from board where b_no =" + cmd);
					Board.result.next(); // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
//					String pass = Board.result.getString("b_pass");
					String no = Board.result.getString("b_no");
					String title = Board.result.getString("b_title");
					String id = Board.result.getString("b_id");
					System.out.println("[" + "번호:" + no + " 제목 : " + title + " 작성자: " + id + "] 을 선택 하였습니다.");
					
					if(SiteMain.loginedId.equals(Board.result.getString("b_id"))&& MemberLogin.log_no.equals(Board.result.getString("log_no"))) {
//					String cmd2 = Ci.r("비밀번호 입력");
//					if (cmd2.equals(pass)) {
						Board.st.executeUpdate("delete from board where b_no=" + cmd);
						System.out.println(" 제목 : " + title + " 가/이 삭제 되었습니다.");
//					} else {
//						System.out.println("비밀번호가 틀렸습니다.");
//					}
					}else {
						System.out.println("작성자가 아닙니다");
					}
				} catch (SQLException e) {
					System.out.println("존재하지 않은 글 입니다.");
				}

				break;
			}
		}
	}
}
