package com.test.board;

import com.test.site.SiteMain;

public class Main {
	public static void main(String[] args) {
		SiteMain.run();		
	}
}
