package com.test.board;

import java.sql.SQLException;

import com.test.util.Ci;

public class MenuRead {
	static void run() {

		System.out.println("<<읽기>>");
		try {
			Board.result = Board.st.executeQuery("select * from board");
			while (Board.result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String no = Board.result.getString("b_no");
				String title = Board.result.getString("b_title");
				String id = Board.result.getString("b_id");
				String best = Board.result.getString("b_hit");
				String report = Board.result.getString("report");
				System.out.println("번호:" + no + " 제목 : " + title + " 작성자: " + id + " <<추천수: " + best + ">>" + "!!신고수: "+report+"!!" );
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String cmd = Ci.r("읽을 글의 번호");
		try {
			Board.result = Board.st.executeQuery("select * from board where b_no =" + cmd);
			Board.result.next(); // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
			String title = Board.result.getString("b_title"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			String content = Board.result.getString("b_text"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			int best = Integer.valueOf(Board.result.getString("b_hit"));
			int report = Integer.valueOf(Board.result.getString("report"));
			System.out.println("글제목: " + title);
			System.out.println("글내용: " + content);

			String best_report = Ci.r("[ 1.추천 / 2.신고 /e.나가기]");
			switch (best_report) {
			case "1":
				System.out.println("이 글을 추천 하시겠습니까?");
				String cmd2 = Ci.r("[ 1.예/2.아니요 ]");
				switch (cmd2) {
				case "1":
					try {
						best = best + 1;
						Board.st.executeUpdate("update board set b_hit = " + best + " where b_no = " + cmd + ";");
						System.out.println("추천 되었습니다.");
					} catch (SQLException e) {
						e.printStackTrace();
					}
					break;
				case "2":
					break;
				default:
					System.out.println("장난치지 마세요");
					break;
				}
			case "2" :
				System.out.println("이 글을 !!신고!! 하시겠습니까?");
				String cmd3 = Ci.r("[ 1.예/2.아니요 ]");
				switch (cmd3) {
				case "1":
					try {
						report = report + 1;
						Board.st.executeUpdate("update board set report = " + report + " where b_no = " + cmd + ";");
						System.out.println("!!신고!! 되었습니다.");
					} catch (SQLException e) {
						e.printStackTrace();
					}
					break;
				case "2":
					break;
				default:
					System.out.println("장난치지 마세요");
					break;
				}
			case "e" :
				break;
			default:
				System.out.println("장난치지 마세요");
				break;
			}

			MenuReply.list(Integer.parseInt(cmd));
		} catch (SQLException e) {
			System.out.println("존재하지 않은 글 입니다.");
//			e.printStackTrace();
		}
	}
}
