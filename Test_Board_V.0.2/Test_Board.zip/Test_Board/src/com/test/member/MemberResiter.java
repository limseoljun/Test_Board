package com.test.member;

import java.sql.SQLException;

import com.test.board.Board;
import com.test.util.Ci;

public class MemberResiter {

	static public void run() {
		System.out.println("==============회원가입===============");
		String user_id;
		String user_pw;
		while(true) {
			user_id=Ci.r("아이디 생성: ");
			if(user_id.length()>0) {
				break;
			}else {
				System.out.println("아이디를 입력해주세요");
			}
		}
		while(true) {
			user_pw=Ci.r("패스워드 생성: ");
			if(user_pw.length()>0) {
				break;
			}else {
				System.out.println("패스워드를 입력해주세요");
			}
		}
		try {
			Board.st.executeUpdate("insert into member(u_id,u_pw,admin_no)values('"+user_id+"','"+user_pw+"','"+0+"')");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("회원가입이 완료되었습니다");
	}
}
