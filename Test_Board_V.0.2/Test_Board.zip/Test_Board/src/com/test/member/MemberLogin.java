package com.test.member;

import java.sql.SQLException;

import com.test.board.Board;
import com.test.util.Ci;

public class MemberLogin {
	public static String log_no = "";

	static public String run() {
		String count = "";
		String admin_no = "";
		System.out.println("==============로그인===============");
		String user_id;
		String user_pw;
		while (true) {
			user_id = Ci.r("아이디 : ");
			if (user_id.length() > 0) {
				break;
			} else {
				System.out.println("아이디를 입력해주세요");
			}
		}
		while (true) {
			user_pw = Ci.r("패스워드 : ");
			if (user_pw.length() > 0) {
				break;
			} else {
				System.out.println("패스워드를 입력해주세요");
			}
		}
		try {
			Board.result = Board.st.executeQuery(
					"select count(*) from member where u_id='" + user_id + "' and u_pw='" + user_pw + "'");
			Board.result.next();
			count = Board.result.getString("count(*)");

			Board.result = Board.st
					.executeQuery("select * from member where u_id='" + user_id + "' and u_pw='" + user_pw + "'");
			Board.result.next();
			log_no = Board.result.getString("m_no");
			admin_no = Board.result.getString("admin_no");
		} catch (SQLException e) {
		}
		if (count.equals("1")) {
			if (admin_no.equals("1")) {
				System.out.println("관리자 아이디로 접속하였습니다.");
				return "관리자";
			}else {
			System.out.println("로그인 성공");
			return user_id;
			}
		} else {
			System.out.println("로그인 실패");
			return null;
		}
	}
}
