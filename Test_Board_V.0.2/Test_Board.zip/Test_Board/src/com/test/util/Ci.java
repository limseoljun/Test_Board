package com.test.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Ci {
	static Scanner sc = new Scanner(System.in);
	static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	static public String r() {
		return sc.next();
	}
	static public String r(String s) {
		System.out.println(s+":");
		return sc.next();
	}
	static public String rl(String s) {
		System.out.println(s+":");
		try {
			return reader.readLine();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	static public String a(String s) {
		System.out.println(s+":");
		return String.valueOf(sc.nextInt());
	}
	static public String b(String s) {
		System.out.println(s+":");
		return sc.nextLine();
	}
	static public int c(String s) {
		System.out.println(s+":");
		return sc.nextInt();
	}
}
