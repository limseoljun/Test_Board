package com.test.admin;

import java.sql.SQLException;

import com.test.board.Board;
import com.test.util.Ci;

public class AdminResiter {
	static void run() {
		String id = "";
		String no = "";
		loop: while(true) {
		String choice = Ci.r("[ 1.관리자 권한부여 / 2.관리자 생성 /e. 나가기 ]");
		switch (choice) {
		case "1":
			System.out.println("============관리자 권한부여=============");
			try {
//				유저 리스트
				Board.result = Board.st.executeQuery("select * from member where admin_no=0");
				while (Board.result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
					id = Board.result.getString("u_id");
					no = Board.result.getString("m_no");
					System.out.println("고유 번호: " + no + " 유저 ID: " + id);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				Board.result = Board.st.executeQuery("select * from member");
				Board.result.next();
				id = Board.result.getString("u_id");
				no = Board.result.getString("m_no");
				String cmd = Ci.r("관리자 권한을 부여할 유저의 고유번호를 입력 해주세요");
				if (cmd.equals(no)) {
					System.out.println("권한을 부여 하시겠습니까??");
					String y_n = Ci.r("[ 1.네 / 2.아니요 ]");
					if (y_n.equals("1")) {
						Board.st.executeUpdate("update member set admin_no=1 where m_no=" + cmd);
						System.out.println(id + "에게 관리자 권한을 부여했습니다.");
					} else if (y_n.equals("2")) {
						System.out.println("취소되었습니다.");
					} else {
						System.out.println("장난치지 마세요");
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			break;
		case "2":
			System.out.println("============관리자 아이디생성=============");
			String ad_id;
			String ad_pw;
			while (true) {
				ad_id = Ci.r("아이디 생성: ");
				if (ad_id.length() > 0) {
					break;
				} else {
					System.out.println("아이디를 입력해주세요");
				}
			}
			while (true) {
				ad_pw = Ci.r("패스워드 생성: ");
				if (ad_pw.length() > 0) {
					break;
				} else {
					System.out.println("패스워드를 입력해주세요");
				}
			}
			try {
				Board.st.executeUpdate(
						"insert into member(u_id,u_pw,admin_no)values('" + ad_id + "','" + ad_pw + "','" + 1 + "')");
			} catch (SQLException e) {
				e.printStackTrace();
			}
			System.out.println("관리자가 생성되었습니다");
			break;
		case "e":
			break loop;
		default:
			System.out.println("장난치지 마세요");
			break;
		}
		}
	}
}
