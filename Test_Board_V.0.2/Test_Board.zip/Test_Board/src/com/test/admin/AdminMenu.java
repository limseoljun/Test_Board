package com.test.admin;

import com.test.util.Ci;

public class AdminMenu {
	public static void run() {
		loop:
			while(true) {
				System.out.println("<<<<<<<<관리자 메뉴>>>>>>>>");
				System.out.println("[ 1.신고글 리스트(신고 많은순) / 2.관리자 권한 부여 및 만들기 /e.뒤로가기]");
				String cmd = Ci.r("명령");
				switch(cmd) {
				case "1":
					// 신고글 리스트
					AdminReport.run();
					break;
				case "2":
					//관리자 권한 및 만들기
					AdminResiter.run();
					break;	
				case "e":
					System.out.println("뒤로가기");
					break loop;
				default:
					System.out.println("장난치지 마세요");
					break;
				}
			}
		}
}
