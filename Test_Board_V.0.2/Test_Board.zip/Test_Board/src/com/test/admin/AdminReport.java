package com.test.admin;

import java.sql.SQLException;

import com.test.board.Board;
import com.test.util.Ci;

public class AdminReport {
	static void run() {
		System.out.println("<<신고된 글>>");
		try {
			Board.result = Board.st.executeQuery("select * from board order by report desc");
			while (Board.result.next()) {
				String no = Board.result.getString("b_no");
				String title = Board.result.getString("b_title");
				String id = Board.result.getString("b_id");
				String datetime = Board.result.getString("b_datetime");
				String report = Board.result.getString("report");
				if (report.equals("0")) {
					break;
				} else {
					System.out.println("번호:" + no + " 제목 : " + title + " 작성자: " + id + " 작성 시간: " + datetime + " !!신고수:"
							+ report + "!!");
				}
			}
		} catch (SQLException e) {
			System.out.println("오류");
		}
		String cmd = Ci.r("읽을 신고글의 번호");
		try {
			Board.result = Board.st.executeQuery("select * from board where b_no =" + cmd);
			Board.result.next();
			String title = Board.result.getString("b_title");
			String content = Board.result.getString("b_text");
			String report = Board.result.getString("report");
			System.out.println("글제목: " + title + "  !!신고수!!" + report);
			System.out.println("글내용: " + content);
			Board.st.executeUpdate("delete from board where b_no=" + cmd);
			System.out.println(" 제목 : " + title + " 가/이 삭제 되었습니다.");
		} catch (SQLException e) {
			System.out.println("오류");
		}

		System.out.println("========================================================");
	}
}
