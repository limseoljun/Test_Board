/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module Test_board02 {
	requires java.sql;
	requires java.naming;
}