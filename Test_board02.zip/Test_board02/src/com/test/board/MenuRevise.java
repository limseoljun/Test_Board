package com.test.board;

import java.sql.SQLException;

import com.test.util.Ci;

public class MenuRevise {
	static void run() {
		 System.out.println("<<글 수정>>");
		 try {
			 Board.result = Board.st.executeQuery("select * from board ");
			 while (Board.result.next()) {
				 String no = Board.result.getString("no");
				 String title = Board.result.getString("title");
				 String id = Board.result.getString("id");
				 String datetime = Board.result.getString("datetime");
				 System.out.println("번호:" + no + " 제목 : " + title + " 작성자: " + id + " 작성 시간: " + datetime);
			 }
		 } catch (SQLException e) {
			 System.out.println("글이 없습니다.");
		 }
		 try {
			String no;
			no = Ci.r("수정할 글의 번호를 입력해 주세요");
			String title = Ci.r("글의 제목 입력");
			String id = Ci.r("작성자 입력");
			String text = Ci.rl("글의 내용 입력");
			Board.st.executeUpdate("update board set title ='"+ title +"',id='"+id+"',text='"+text+ "' where no ="+ no );
			System.out.println("수정되었습니다.");
		 } catch (SQLException e) {
			e.printStackTrace();
		}
		 
	 }
}
