package com.test.board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.test.display.Disp;

public class Board {
	static Connection con = null;
	static Statement st = null;
	static ResultSet result = null;

	void run() {
		Disp.title();
		dbinit();
		Menu.run();
	}

	void dbinit() {
	 try{
	 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_board", "root", "0000");
	 st = con.createStatement();
	 }catch(SQLException e){
		 e.printStackTrace();
	 }
 }

}
