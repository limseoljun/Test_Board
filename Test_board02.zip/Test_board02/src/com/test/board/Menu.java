package com.test.board;

import com.test.display.Disp;
import com.test.util.Ci;

public class Menu {
	public static void run() {
		Disp.menuMain();
		loop:
			while(true) {
				String cmd = Ci.r("명령: ");
				switch(cmd) {
				case "1":
					//리스트
					MenuList.run();
					break;
				case "2":
					//읽기
					MenuRead.run();
					break;
				case "3":	
					//쓰기
					MenuWrite.run();
					break;
				case "4":
					//삭제
					MenuDel.run();
					break;
				case "5":
					//수정
					MenuRevise.run();
					break;
					
				case "e":
					System.out.println("프로그램 종료");
					break loop;
				default:
					System.out.println("장난치지 마세요");
					break;
				}
			}
	}
}
