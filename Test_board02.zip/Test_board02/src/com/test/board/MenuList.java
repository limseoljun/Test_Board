package com.test.board;

import java.sql.SQLException;

public class MenuList {
	static void run() {
		System.out.println("==========================================");
		System.out.println("================= 글리스트 ==================");
		System.out.println("==========================================");
		try {
			Board.result = Board.st.executeQuery("select * from board ");
			while (Board.result.next()) { 
				String no = Board.result.getString("no");
				String title = Board.result.getString("title");
				String id = Board.result.getString("id");
				String datetime = Board.result.getString("datetime");
				System.out.println("번호:" + no + " 제목 : " + title + " 작성자: " + id + " 작성 시간: " + datetime);
			}
		} catch (SQLException e) {
			System.out.println("글이 없습니다.");
		}
	}
}
