package com.test.board;

import java.sql.SQLException;

import com.test.util.Ci;

public class MenuWrite {
	public static void run() {
		 System.out.println("<<글 쓰기>>");
		 try {
			String title = Ci.r("글 제목 입력: ");
			String id = Ci.r("작성자명 입력: ");
			String content = Ci.rl("글 내용 입력: ");
			Board.st.executeUpdate("insert into board(title,id,text,hit,datetime)values('"+title+"','"+id+"','"+content+"',0,now());");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
