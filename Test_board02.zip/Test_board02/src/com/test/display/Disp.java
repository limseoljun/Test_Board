package com.test.display;

public class Disp {
	public static void title() {
		for (int i = 0; i < 32; i++) {
			System.out.print("◇");
		}
		System.out.println();
		System.out.print("◇");
		for (int i = 0; i < 13; i++) {
			System.out.print(" ");
		}
		System.out.print("게시판");
		for (int i = 0; i < 13; i++) {
			System.out.print(" ");
		}
		System.out.print("◇‍");
		System.out.println();
		for (int i = 0; i < 32; i++) {
			System.out.print("◇‍");
		}
		System.out.println();
	}

	public static void menuMain() {
		System.out.print("🐈‍");
		System.out.print("[1.글 리스트/2.글읽기/3.글쓰기/4.글삭제/5.글수정/e.종료]");
		System.out.print("🐈‍");
		System.out.println();
	}

	public static void replyBar() {
		System.out.println("================= 댓글 리스트 ==================");
	}

}
